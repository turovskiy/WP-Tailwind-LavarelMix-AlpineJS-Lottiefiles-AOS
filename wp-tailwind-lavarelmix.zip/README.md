# WP-Tailwind-LaravelMix-AlpineJS-Lottiefiles-AOS
Шаблон теми Wordpress на стероїдах)

