<?php
/*
 * Template Name: Null Page Template
 * Template Post Type: post, page, whatever
 */

get_header();

?>
	<p>Это пример шаблона</p>
<?php

get_footer();