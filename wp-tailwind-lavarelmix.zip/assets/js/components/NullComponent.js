module.exports = {

    init: function () {
        // робити щось тут
        //alert('Супер! Код працює....');
    }

};