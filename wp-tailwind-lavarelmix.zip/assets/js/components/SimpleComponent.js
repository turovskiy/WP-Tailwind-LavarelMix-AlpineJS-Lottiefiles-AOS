// const $ = window.jQuery;
// const $window = window.$window || $(window);

// const SimpleComponent = {

//     init() {
//         var $module = $('.SimpleComponent');
//         if (!$module.length)
//             return;

//         $module.each((index, element) => {
//             this.each(element);
//         });
//     },

//     each(element) {

//         let $item = $(element);

       // робити щось тут
        //alert('Супер! Код працює....');

    // }

// };

// export default SimpleComponent;