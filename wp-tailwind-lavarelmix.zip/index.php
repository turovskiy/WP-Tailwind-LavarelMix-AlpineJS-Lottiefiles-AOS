<?php

get_header();

get_template_part( 'templates/partials/home' );

get_footer();